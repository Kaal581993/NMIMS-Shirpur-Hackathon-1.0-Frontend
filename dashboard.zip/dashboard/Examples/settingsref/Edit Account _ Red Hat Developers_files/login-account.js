/* Common JS logic for all login/account pages */

/*
 * Common utility methods
 */
var Util = function() {
	
    this.syncAndRemoveCheckbox = function(checkbox, checkboxHidden) {
    	if(checkbox && checkboxHidden){
        	checkboxHidden.attr('value', checkbox.is(':checked') ? 'yes' : 'no');
        	// push just hidden value and don't rely on checkbox input element
        	checkbox.attr("disabled", true);
    	}
    };
    
    this.stringContains = function(string, substring){
    	return string.indexOf(substring) > -1;
    };
    
    this.getCookie = function(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for(var i=0; i<ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
        }
        return "";
    };
    
    this.deleteCookie = function(name) {
        document.cookie = name + '=;path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    };

    this.handleDownloadTexts = function(){
    	// Download UI texts handling
    	var hint = util.getCookie('rhd-reg-hint');
    	// get info from cookie if we are in download flow to modify some texts
    	if(hint.indexOf('fulluser') > -1 || hint.indexOf('companycountry') > -1){
    		$('.download-hide').remove();
    		$('.download-show').show();
    	} else {
    		$('.download-show').remove();
    	}
    };

    
    var modalActiveClass = "modal-active";
    this.toggleModal = function(id) {
        var modalWindow = $("#"+id);
        var isModalActive = modalWindow.hasClass(modalActiveClass);
        modalWindow.toggleClass("modal-active");
        if (isModalActive) {
            var popupMask = $("#PopupMask");
            if (popupMask != null)  {
                popupMask.remove();
            }
            modalWindow.css( "z-index" , $("#"+id).data('saveZindex') );
        } else {
            $("body").prepend("<div id='PopupMask' style='position:fixed;width:100%;height:100%;z-index:10;background-color:gray;'></div>");
            $("#PopupMask").css('opacity', 0.7);
            modalWindow.data('saveZindex', modalWindow.css( "z-index"));
            modalWindow.css( "z-index" , 11);
        }
    };
    
    /*
     * Take request param called "un" and fill its value into form field with id "username" 
     */
    this.fillUsernameFieldFromParam = function(){
    	var un = qs["un"];
    	if(un){
    		$('#username').val(un);
    	}
    };
    
    /*
     * parse query string and place it's elements into qs map
     */
    var qs = (function(a) {
        if (a == "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i)
        {
            var p=a[i].split('=', 2);
            if (p.length == 1)
                b[p[0]] = "";
            else
                b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
    })(window.location.search.substr(1).split('&'));
};
util = new Util();

var AdaptivePlaceholder = function() {

    this.changeFilledState = function (elm) {
        var input = $(elm);
        var value = input.val();

        if (value !== "" && value != undefined) {
            input.addClass('filled');
        } else {
            input.removeClass('filled');
        }
    };
};
adaptivePlaceholder = new AdaptivePlaceholder();


var LoginForm = function () {
    this.init = function (form, err) {
    	form.submit(function( event ) {
    		//event.preventDefault();
    		sendFormSubmissionEvent('login','Log In', form[0]);
    	});
    	
    	if(err && err.length > 0){
    	  sendFormErrorsArrayEvent(form[0].id, 'login','Log In', err);
    	} else {
          sendFormLoadEvent(form[0].id, 'login','Log In');
    	}
    }
};
loginForm = new LoginForm();
    	

/*
 * Javascripts for validation of user Registration form (login/register.ftl).
 * initValidation() must be called during page initialization.
 */
var RegisterForm = function () {
    this.initValidation = function (regForm) {
    	
    	var validateConfig = {
            submitHandler: function(form) {
                util.syncAndRemoveCheckbox($('#user\\.attributes\\.newsletter'), $('#user\\.attributes\\.newsletter\\.hidden'));
                sendFormSubmissionEvent('register','Register', form);
                form.submit();
            },
            invalidHandler: function(event, validator) {
            	sendFormErrorsEvent(regForm[0].id, 'register','Register', validator);
            },
            rules: {
                password: {required: true, minlength: 6},
                "password-confirm": {required: true, equalTo: "#password" }
            },
            messages: {
                password: {required: "Password is required"},
                "password-confirm": { required: "Type in password again",  equalTo: "Passwords don't match" }
            }
        };
    	
    	setupRhdBasicUserValidations(validateConfig, true);

        
    	// terms handling
    	setupRhdTCValidations(validateConfig, true, true, true);
    	
        regForm.validate(validateConfig);
        
        sendFormLoadEvent(regForm[0].id, 'register','Register');
    }
};
registerForm = new RegisterForm();

/*
 * Javascripts for validation of user account update form shown during login flows (login/login-update-profile.ftl).
 * initValidation() must be called during page initialization.
 */
var UpdateForm = function () {
	var updformType = "login-profile-update";
	var updformName = "Additional Action Required";
    this.initValidation = function (regForm, isFirstSocialLoginFlow, enterPassword, enterUserProfile, enterRhdTac, enterAdditionalTac, enterPortalTac) {
    	
    	if(isFirstSocialLoginFlow){
    		updformType = "register-social";
    		updformName = "Register using a social account";
    	}
    	
    	var validateConfig = {
            submitHandler: function(form) {
                util.syncAndRemoveCheckbox($('#user\\.attributes\\.newsletter'), $('#user\\.attributes\\.newsletter\\.hidden'));
                sendFormSubmissionEvent(updformType, updformName, form);
                form.submit();
            },
            invalidHandler: function(event, validator) {
            	sendFormErrorsEvent(regForm[0].id, updformType, updformName, validator);
            },
            rules: {
            },
            messages: {
                "user.attributes.pwd": {required: "Password is required"},
                "password-confirm": {required: "Type in password again", equalTo: "Passwords don't match"}
            }
        };
    	
    	if(enterUserProfile){
    		setupRhdBasicUserValidations(validateConfig, true);
    	}

    	if(enterPassword){
		  validateConfig.rules["user.attributes.pwd"] = { required: true,  minlength: 6 };
		  validateConfig.rules["password-confirm"] = { required: true, equalTo: "#user\\.attributes\\.pwd" };
    	}
        
    	// terms handling
    	setupRhdTCValidations(validateConfig, enterRhdTac, enterAdditionalTac, enterPortalTac);
    	
        regForm.validate(validateConfig);
        
        sendFormLoadEvent(regForm[0].id, updformType, updformName);
    }
};
updateForm = new UpdateForm();

/*
 * Javascripts for validation of user profile form shown in account app (account/account.ftl).
 * initValidation() must be called during page initialization.
 */
var ProfileForm = function () {
    this.initValidation = function (regForm) {
    	
    	var validateConfig = {
    		submitHandler: function(form) {
              sendFormSubmissionEvent('profile-edit','Edit account', form);
              form.submit();
            },
            invalidHandler: function(event, validator) {
              sendFormErrorsEvent(regForm[0].id,'profile-edit','Edit account', validator);
            },
    		rules: {
            },
            messages: {
            }
        };
    	
  		setupRhdBasicUserValidations(validateConfig,true);

        regForm.validate(validateConfig);
        sendFormLoadEvent(regForm[0].id,'profile-edit','Edit account');
    }
};
profileForm = new ProfileForm();


function setupRhdBasicUserValidations(validateConfig, emailRemoteVerification){
	validateConfig.rules["email"] = {required: true, email: true, bannedCharsEmail:true};
	if (emailRemoteVerification){
		validateConfig.rules.email["onkeyup"] = false;
		validateConfig.rules.email["remote"] = {
	        url: "/auth/realms/rhd/rhdtools/emailUsed",
	        type: "post",
	        cache: false,
	        contentType: "application/json",
	        async: true,
	        dataProcess: true,
	        beforeSend: function(jqXHR, settings) {
	            settings.data = JSON.stringify(
	                {
	                    email: $("#email").val(),
	                    username: $("#email").attr("data-uname")
	                }
	            );
	        },
	        dataFilter: function(response) {
	            return !$.parseJSON(response).exists;
	        }
	    };
	} 
    var loginUrl = $("#email").attr("data-login-url");
	validateConfig.messages["email"] = {required: "Email is required", remote: "User account for this email already exists. " + loginUrl};
	validateConfig.rules["firstName"] = {required: true, maxlength: 45, bannedChars : true};
	validateConfig.messages["firstName"] = {required: "First name is required"};
	validateConfig.rules["lastName"] = {required: true, maxlength: 45, bannedChars : true};
	validateConfig.messages["lastName"] = {required: "Last name is required"};
	validateConfig.rules["user.attributes.company"] = {required: true, maxlength: 45, bannedChars : true};
	validateConfig.messages["user.attributes.company"] = {required: "Company name is required"};
	validateConfig.rules["user.attributes.country"] = {required: true, bannedChars : true};
	validateConfig.messages["user.attributes.country"] = {required: "Country is required"};

    validateConfig.rules["user.attributes.addressState"] = {required: function() {
        return $("#user\\.attributes\\.addressState").is(':visible');
    }};
    validateConfig.messages["user.attributes.addressState"] = {required: "State/Province is required"};
    validateConfig.rules["user.attributes.addressCity"] = {required: function() {
        return $("#user\\.attributes\\.addressCity").is(':visible');
    }};
    validateConfig.messages["user.attributes.addressCity"] = {required: "City is required"};

    validateConfig.rules["user.attributes.phoneNumber"] = {required: true, maxlength: 45, phone: true };
    validateConfig.messages["user.attributes.phoneNumber"] = {required: "Phone number is required"};

}


function setupRhdTCValidations(validateConfig, enterRhdTac, enterAdditionalTac, enterPortalTac){
	if(enterRhdTac){
		validateConfig.rules["user.attributes.tcacc-1246"] = {required: true};
		validateConfig.messages["user.attributes.tcacc-1246"] = {required: "You have to agree with Terms and Conditions"};
	}
	if(enterAdditionalTac){
		validateConfig.rules["user.attributes.tcacc-6"] = {required: true};
		validateConfig.messages["user.attributes.tcacc-6"] = {required: "You have to agree with Terms and Conditions"};
	}
	if(enterPortalTac){
		validateConfig.rules["user.attributes.tcacc-1010"] = {required: true};
		validateConfig.messages["user.attributes.tcacc-1010"] = {required: "You have to agree with Terms and Conditions"};
	}
}

/*
 * Object used to handle Address part of user form. Mainly to show correct input field types and change them dynamically.
 * init() must be called during page initialization.
 */
var AddressForm = function () {

	/* Object containing country codes as a key and object with states as a value (object with states has state codes as a keys and state names as a values) */
	var statesByCountry = {};
	statesByCountry["US"] = {
		AL:"Alabama", AK:"Alaska", AZ:"Arizona", AR:"Arkansas",CA:"California",CO:"Colorado",CT:"Connecticut",DE:"Delaware",DC:"District Of Columbia",FL:"Florida",GA:"Georgia",HI:"Hawaii",ID:"Idaho",IL:"Illinois",IN:"Indiana",IA:"Iowa",KS:"Kansas",KY:"Kentucky",LA:"Louisiana",ME:"Maine",MD:"Maryland",MA:"Massachusetts",MI:"Michigan",MN:"Minnesota",MS:"Mississippi",MO:"Missouri",MT:"Montana",NE:"Nebraska",NV:"Nevada",NH:"New Hampshire",NJ:"New Jersey",NM:"New Mexico",NY:"New York",NC:"North Carolina",ND:"North Dakota",OH:"Ohio",OK:"Oklahoma",OR:"Oregon",PA:"Pennsylvania",RI:"Rhode Island",SC:"South Carolina",SD:"South Dakota",TN:"Tennessee",TX:"Texas",UT:"Utah",VT:"Vermont",VA:"Virginia",WA:"Washington",WV:"West Virginia",WI:"Wisconsin",WY:"Wyoming",AS:"American Samoa",GU:"Guam",MP:"Northern Marianas",PW:"Palau",PR:"Puerto Rico",VI:"Virgin Islands",AA:"Armed Forces(AA)",AE:"Armed Forces(AE)",AP:"Armed Forces(AP)"
		};
	statesByCountry["CA"] = {
        AB:"Alberta",BC:"British Columbia",MB:"Manitoba",NB:"New Brunswick",NL:"Newfoundland",NT:"Northwest Territory",NS:"Nova Scotia",NU:"Nunavut Territory",ON:"Ontario",PE:"Prince Edward Island",QC:"Quebec",SK:"Saskatchewan",YT:"Yukon Territory"
		};
	statesByCountry["MX"] = {
        AG:"Aguascalientes", BC:"Baja California", BS:"Baja California Sur", CH:"Chihuahua", CL :"Colima", CM:"Campeche", CO:"Coahuila", CS:"Chiapas", DF:"Distrito Federal", DG:"Durango",	GR:"Guerrero", GT:"Guanajuato",HG:"Hidalgo",JA:"Jalisco",MI:"Michoacan",MO:"Morelos",MX:"Mexico",NA:"Nayarit",NL:"Nuevo Leon",OA:"Oaxaca",PU:"Puebla",QR:"Quintana Roo",QT:"Queretaro", SI:"Sinaloa",SL:"San Luis Potosi",SO:"Sonora",TB:"Tabasco",TL:"Tlaxcala",TM:"Tamaulipas",VE:"Veracruz", YU:"Yucatan",ZA:"Zacatecas"
		};

	var fillSelect = function(selectField, options, selectedValue) {
        selectField.find('option').remove();
        selectField.append($("<option />").val("").text(""));
        for(var key in options){
            var val = options[key];
            var item = $("<option />").val(key).text(options[key]);
            if (val == selectedValue) {
                item.selected(true);
            }
			selectField.append(item);
		}
	};

    var countryField, addressStateContainer, addressStateField, addressCityContainer;

	this.init = function() {
        countryField = $("#user\\.attributes\\.country");
        addressStateContainer = $("#addressStateContainer");
        addressStateField = $("#user\\.attributes\\.addressState");
        addressCityContainer = $("#addressCityContainer");

        addressForm.countryChanged();
        countryField.change(function() {
            addressForm.countryChanged();
        });

	};


    /* Handles necessary changes in the form if country is changed.
     * @param keepValues if true then actual values of the form fields are kept - useful after page is shown pre-filled from server side
     */
    this.countryChanged = function() {
        var country = countryField.val();
        var addressStateError = $("#user\\.attributes\\.addressState-error");
        var addressCityError = $("#user\\.attributes\\.addressCity-error");

        if (isStateRequired(country)) {
            var options = statesByCountry[country];
            var initValue = addressStateField.attr("data-value");
            fillSelect(addressStateField, options, initValue);

            addressStateContainer.show();
            addressStateError.show();
        } else {
            addressStateContainer.hide();
            addressStateError.hide();
        }

        if (isCityRequired(country)) {
            addressCityContainer.show();
            addressCityError.show();
        } else {
            addressCityContainer.hide();
            addressCityError.hide();
        }
	};
	var isStateRequired = function(country) {
        if (statesByCountry[country]) {
            return true;
        }
        return false;
    };
    var isCityRequired = function(country) {
        if (country == "UA" || statesByCountry[country]) {
            return true;
        }
        return false;
    };
};
addressForm = new AddressForm();

/*
 * Password update page javascripts (account/password.ftl and login/login-update-password.ftl).
 * initPasswordValidation() must be called during page initialization.
 */
var PasswordForm = function () {
	var pwformType = "";
	var pwformName = "";
    this.initValidation = function (regForm, dtmFormType, dtmFormName) {
    	pwformType = dtmFormType;
    	pwformName = dtmFormName;
        regForm.validate({
        	submitHandler: function(form) {
                sendFormSubmissionEvent(pwformType, pwformName, form);
                form.submit();
            },
            invalidHandler: function(event, validator) {
            	sendFormErrorsEvent(regForm[0].id, pwformType, pwformName, validator);
            },
            rules: {
            	"password": {required: true, minlength: 1 },
                "password-new": {required: true, minlength: 6 },
                "password-confirm": { required: true, equalTo: "#password-new"}
            },
            messages: {
            	"password": {
                    required: "Current password is required"
                },
                "password-new": {
                    required: "New password is required"
                },
                "password-confirm": {
                    required: "Type in password again",
                    equalTo: "Passwords don't match"
                }
            }
        });
        sendFormLoadEvent(regForm[0].id, pwformType, dtmFormName);
    }
};
passwordForm = new PasswordForm();

/*
 * Forgot Password request page javascripts (login/login-reset-password.ftl).
 * initValidation() must be called during page initialization.
 */
var ForgotPasswordReqForm = function () {
    this.initValidation = function (regForm) {
        regForm.validate({
        	submitHandler: function(form) {
                sendFormSubmissionEvent("fp-request", "Forgot your password?", form);
                form.submit();
            },
            invalidHandler: function(event, validator) {
            	sendFormErrorsEvent(regForm[0].id, "fp-request", "Forgot your password?", validator);
            },
            rules: {
            	"username": {required: true}
            },
            messages: {
            	"username": {
                    required: "Username or email is required"
                }
            }
        });
        sendFormLoadEvent(regForm[0].id, "fp-request", "Forgot your password?");
    }
};
forgotPasswordReqForm = new ForgotPasswordReqForm();


/**
 * Creates and dispatches an DTM event trigger
 * @param {String} evt - The name of the event
 */
function sendCustomEvent(evt){
  if(document.createEvent && document.body.dispatchEvent){
    var event = document.createEvent('Event');
    event.initEvent(evt, true, true); //can bubble, and is cancellable
    document.body.dispatchEvent(event);
  } else if(window.CustomEvent && document.body.dispatchEvent) {
    var event = new CustomEvent(evt, {bubbles: true, cancelable: true});
    document.body.dispatchEvent(event);
  }
}

/**
 * Creates and dispatches an DTM form load event
 */
function sendFormLoadEvent(formId, formType, formName){
  if (window.digitalData) {
	var ddFormEvent = {
		eventInfo: {
		  eventAction: 'formLoad',
		  eventName: 'formLoad',
		  formId: formId,
		  formName: formName,
		  formStep: 'view',
		  formType: formType,
		  offerId: '',
		  timeStamp: new Date(),
		  processed: {
		    adobeAnalytics: false
		  }
		}
	};
	window.digitalData = window.digitalData || {};
	digitalData.event = digitalData.event || [];
	digitalData.event.push(ddFormEvent);
	sendCustomEvent('formEvent');
  }
}

/**
 * Creates and dispatches an DTM form submission event
 */
function sendFormSubmissionEvent(formType, formName, formDom){
  if (window.digitalData) {	
	var ddFormEvent = {
		eventInfo: {
		  eventAction: 'formSubmission',
		  eventName: 'formSubmit',
		  formId: formDom.id,
		  formName: formName,
		  formStep: 'submit',
		  formType: formType,
		  offerId: '',
		  fieldValues: [],
		  timeStamp: new Date(),
		  processed: {
		    adobeAnalytics: false
		  }
		}
	};
	
	for (var i = 0; i < formDom.length; i++) {
		if(formDom.elements[i].type != "submit" && formDom.elements[i].type != "hidden" && formDom.elements[i].type != "password" && !formDom.elements[i].disabled){
			var en = formDom.elements[i].name;
			if(en && en.indexOf("password") == -1 && en.indexOf("pwd") == -1){
				if(formDom.elements[i].type != "checkbox" || formDom.elements[i].checked){
				  ddFormEvent.eventInfo.fieldValues.push(en+":"+formDom.elements[i].value);
				}
			}
		}
	}
	
	window.digitalData = window.digitalData || {};
	digitalData.event = digitalData.event || [];
	digitalData.event.push(ddFormEvent);
	sendCustomEvent('formEvent');
  }
}


function sendSocialLinkEvent(sprov){
  if (window.digitalData) {	
	var ddSocialLinkEvent = {
	  eventInfo: {
	    eventAction: 'link',
	    eventName: 'social account link',
	    socialAccount: sprov,
	    socialAccountsLinked: ['<string>', '<string>', '<string>'],
	    timeStamp: new Date(),
	    processed: {
	      adobeAnalytics: false
	    }
	  }
	};
	ddSocialLinkEvent.eventInfo.socialAccountsLinked = digitalData.user[0].profile[0].profileInfo.socialAccountsLinked;
	window.digitalData = window.digitalData || {};
	digitalData.event = digitalData.event || [];
	digitalData.event.push(ddSocialLinkEvent);
	sendCustomEvent('socialLinkEvent'); 
  }	
}

/**
 * Creates and dispatches an DTM form submission error event with errors taken from jquery validator
 */
function sendFormErrorsEvent(formId, formType, formName, validator){
  if (window.digitalData) {
	var em = [];
	for (var i in validator.errorMap) {
		em.push(i + ":" + validator.errorMap[i]);
	}
	sendFormErrorsArrayEvent(formId, formType, formName, em);
  }
}

/**
 * Creates and dispatches an DTM form submission error event with errors array pushed in as third param
 */
function sendFormErrorsArrayEvent(formId, formType, formName, errorMessage){
  if (window.digitalData) {

	  var ddFormEvent = {
		eventInfo: {
		  eventAction: 'formSubmission',
		  eventName: 'formSubmit',
		  formId: formId,
		  formName: formName,
		  formStep: 'error',
		  formType: formType,
		  offerId: '',
		  errorMessage: [],
		  timeStamp: new Date(),
		  processed: {
		    adobeAnalytics: false
		  }
		}
	};
	
	if(errorMessage){
	  ddFormEvent.eventInfo.errorMessage = errorMessage;
	}

	window.digitalData = window.digitalData || {};
	digitalData.event = digitalData.event || [];
	digitalData.event.push(ddFormEvent);
	sendCustomEvent('formEvent');
  }	
}


/*
 * jquery Validation settings
 */
jQuery.validator.setDefaults({
    errorElement: "span",
    errorPlacement: function(error, element) {
        if (element.attr('type') == 'checkbox') {
            error.insertAfter( $("label[for='" + element.attr('id') + "']") );
        } else {
            error.insertAfter( element.parent() );
        }
    },
    onkeyup: function(element) {
        var element_id = $(element).attr('id');
        if (this.settings.rules[element_id] && this.settings.rules[element_id].onkeyup !== false) {
            $.validator.defaults.onkeyup.apply(this, arguments);
        }
    },
    highlight: function( element, errorClass, validClass ) {
        if ( element.type === "radio" ) {
            this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );
            this.findByName( element.name ).parent().addClass( errorClass ).removeClass( validClass );
        } else {
            $( element ).addClass( errorClass ).removeClass( validClass );
            $( element ).parent().addClass( errorClass ).removeClass( validClass );
        }
    },
    unhighlight: function( element, errorClass, validClass ) {
        if ( element.type === "radio" ) {
            this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );
            this.findByName( element.name ).parent().removeClass( errorClass ).addClass( validClass );
        } else {
            $( element ).removeClass( errorClass ).addClass( validClass );
            $( element ).parent().removeClass( errorClass ).addClass( validClass );
        }
    }
});

/*
 * Additional validators
 */
jQuery.validator.addMethod("required", function(value, element) {
    return $.trim(value);
}, "This field is required");

jQuery.validator.addMethod("phone", function(value, element) {
	var re = new RegExp('^\\+?[0-9\\.\\- ]+$');
    return re.test(value);
}, "This field may only contain the following characters (0-9) (+) (-) (space) (.).");

jQuery.validator.addMethod("bannedChars", function(value, element) {
    return !(util.stringContains(value,"\"") || util.stringContains(value,"$") || util.stringContains(value,"^") || util.stringContains(value,"<") || util.stringContains(value,">") || util.stringContains(value,"|") || util.stringContains(value,"+") || util.stringContains(value,"%") || util.stringContains(value,"\\"));
}, "This field cannot contain the following special characters (\") ($) (^) (<) (>) (|) (+) (%) (\\).");

jQuery.validator.addMethod("bannedCharsEmail", function(value, element) {
    return !(util.stringContains(value,"$") || util.stringContains(value,"^") || util.stringContains(value,"|") || util.stringContains(value,"%") || util.stringContains(value,"\\") || util.stringContains(value,"~") || util.stringContains(value,"*") || util.stringContains(value,"="));
}, "Email field cannot contain the following special characters ($) (^) (|) (%) (\\) (~) (*) (=).");


